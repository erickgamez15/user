package com.bitala.api.mantenimiento.users.constants;

public class FacturaConstantes {
    public static final String SOMETHING_WENT_WRONG = "Algo salió mal";

    public static final String INVALID_DATA = "Datos inválidos";

    public static final String UNAUTHORIZED_ACCESS = "Acceso no autorizado";
}
